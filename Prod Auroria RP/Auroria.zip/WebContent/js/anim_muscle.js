$(window).on('load', function(){
	$('#partie-1').hide()
	$('#partie-2').hide()
	$('#partie-3').hide()
	$('#partie-4').hide()
	$('#partie-5').hide()
	$('#partie-6').hide()
	$('#partie-7').hide()
	$('#partie-8').hide()
	$('#partie-9').hide()
	$('#partie-10').hide()
	$('#partie-11').hide()
	$('#partie-12').hide()
	$('#partie-13').hide()
	$('#partie-14').hide()
	$('#partie-15').hide()
	$('#partie-16').hide()
	$('#partie-17').hide()
	$('#partie-18').hide()
	$('#partie-19').hide()
	$('#partie-20').hide()
	$('#partie-21').hide()
	$('#partie-22').hide()
	$('#partie-23').hide()
	$('#partie-24').hide()
	$('#partie-25').hide()
	$('#partie-26').hide()
	$('#partie-27').hide()
	$('#partie-28').hide()
})
$(function(){
	setInterval(function(){
		$('#partie-1').slideDown(5000, function(){
			$('#partie-2').slideDown(4900, function(){
				$('#partie-3').slideDown(4800, function(){
					$('#partie-4').slideDown(4700, function(){
						$('#partie-5').slideDown(4600, function(){
							$('#partie-6').slideDown(4500, function(){
								$('#partie-7').slideDown(4400, function(){
									$('#partie-8').slideDown(4300, function(){
										$('#partie-9').slideDown(4200, function(){
											$('#partie-10').slideDown(4100, function(){
												$('#partie-11').slideDown(4000, function(){
													$('#partie-12').slideDown(3900, function(){
														$('#partie-13').slideDown(3800, function(){
															$('#partie-14').slideDown(3700, function(){
																$('#partie-15').slideDown(3600, function(){
																	$('#partie-16').slideDown(3500, function(){
																		$('#partie-17').slideDown(3400, function(){
																			$('#partie-19').slideDown(3300, function(){
																				$('#partie-20').slideDown(3200, function(){
																					$('#partie-21').slideDown(3100, function(){
																						$('#partie-22').slideDown(3000, function(){
																							$('#partie-23').slideDown(2800, function(){
																								$('#partie-24').slideDown(2600, function(){
																									$('#partie-25').slideDown(2400, function(){
																										$('#partie-26').slideDown(2000, function(){
																											$('#partie-27').slideDown(1500, function(){
																												$('#partie-28').slideDown(1000)
																											})
																										})
																									})
																								})
																							})
																						})
																					})
																				})
																			})
																		})
																	})
																})
															})
														})
													})
												})
											})
										})
									})
								})
							})
						})
					})
				})
			})
		})
	})
})