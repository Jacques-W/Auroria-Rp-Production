$(window).on('load', function(){
	$('#partie-1').hide()
	$('#partie-2').hide()
	$('#partie-3').hide()
	$('#partie-4').hide()
	$('#partie-5').hide()
	$('#partie-6').hide()
	$('#partie-7').hide()
	$('#partie-8').hide()
	$('#partie-9').hide()
	$('#partie-10').hide()
	$('#partie-11').hide()
	$('#partie-12').hide()
	$('#partie-13').hide()
	$('#partie-14').hide()
})
$(function(){
	setInterval(function(){
		$('#partie-1').slideDown(5000, function(){
			$('#partie-2').slideDown(4800, function(){
				$('#partie-3').slideDown(4600, function(){
					$('#partie-4').slideDown(4400, function(){
						$('#partie-5').slideDown(4200, function(){
							$('#partie-6').slideDown(4000, function(){
								$('#partie-7').slideDown(3800, function(){
									$('#partie-8').slideDown(3600, function(){
										$('#partie-9').slideDown(3400, function(){
											$('#partie-10').slideDown(3200, function(){
												$('#partie-11').slideDown(3000, function(){
													$('#partie-12').slideDown(2500, function(){
														$('#partie-13').slideDown(2000, function(){
															$('#partie-14').slideDown(1000)
														})
													})
												})
											})
										})
									})
								})
							})
						})
					})
				})
			})
		})
	})
})