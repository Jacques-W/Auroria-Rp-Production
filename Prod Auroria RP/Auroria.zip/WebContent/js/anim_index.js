$(window).on('load', function(){
	$('#partie-1').hide()
	$('#partie-2').hide()
	$('#partie-3').hide()
})
$(function(){
	setInterval(function(){
		$('#partie-1').slideDown(3000, function(){
			$('#partie-2').slideDown(2000, function(){
				$('#partie-3').slideDown(1000)
			})
		})
	})
})