$(window).on('load', function(){
	$('#partie-1').hide()
})
$(function(){
	setInterval(function(){
		$('#partie-1').slideDown(1000)
	})
})