$(window).on('load', function(){
	$('#partie-1').hide()
	$('#partie-2').hide()
	$('#partie-3').hide()
	$('#partie-4').hide()
	$('#partie-5').hide()
	$('#partie-6').hide()
	$('#partie-7').hide()
	$('#partie-8').hide()
})
$(function(){
	setInterval(function(){
		$('#partie-1').slideDown(5000, function(){
			$('#partie-2').slideDown(4500, function(){
				$('#partie-3').slideDown(3000, function(){
					$('#partie-4').slideDown(2500, function(){
						$('#partie-5').slideDown(2000, function(){
							$('#partie-6').slideDown(1500, function(){
								$('#partie-7').slideDown(1200, function(){
									$('#partie-8').slideDown(1000)
								})
							})
						})
					})
				})
			})
		})
	})
})