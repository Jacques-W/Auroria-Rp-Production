<!doctype html>
<html>
 
<?php 
    include 'include/traitement.php';
?>
 
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
   <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> -->
	
	<link rel="stylesheet" href="css/bootstrap.css">


    <title>Auroria RP</title>
 
  </head>
 
<body>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 
 
	<header>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-3">
			<h2 class="text-danger">Auroria R&ocirc;lePlay</h2>
				<a class="navbar-brand" href="#"></a>
	  				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    				<span class="navbar-toggler-icon"></span>
	  				</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
	    		<ul class="navbar-nav ml-auto">
	      			<li class="nav-item active">
							<a class="nav-link" href="index.html">Accueil</a>
						</li>
						<li class="nav-item active">
							<a class="nav-link" href="background.html">Notre Histoire</a>
						</li>
						<li class="nav-item active">
							<a class="nav-link" href="creationBackgroundPerso.php">Cr&eacute;er son background</a>
						</li>
						<li class="nav-item active">
							<a class="nav-link" href="background-perso.php">Background Personnages</a>
						</li>
						<li class="nav-item active">
							<a class="nav-link" href="rules.html">Notre Code P&eacute;nal</a>
						</li>
						<li class="nav-item active">
							<a class="nav-link" href="concess_main.html">Le Concessionnaire</a>
						</li>
						<li class="nav-item active">
							<a class="nav-link" href="contact.php">Nous contacter</a>
						</li>
	    		</ul>
	  		</div>
		</nav>
	</header>
	<section class="container-fluid bg-secondary text-light">
		<section class="container bg-dark">
			<div class="row text-center">
				<div class="col-md-12 py-5">
					<h2 class="text-danger">Vous &ecirc;tes sur la page de contact !!<br> Posez vos questions ou autres</h2>
				</div>
			</div>
		</section>
		<section class="container bg-dark text-light">
			<div id="form" class="col text-center">
				<form id="contact" method="post">
   					<fieldset><legend>Vos coordonn&eacute;es</legend>
    					<p><label for="nom">Nom :</label><br>
    						<input type="text" id="nom" name="nom" /></p>
    					<p><label for="email">Email :</label><br>
    						<input type="text" id="email" name="email" /></p>
    				</fieldset>
     				<fieldset><legend>Votre message :</legend>
    					<p><label for="objet">Objet et R&ocirc;le :</label><br>
    						<input type="text" id="objet" name="objet" /></p>
    					<p><label for="message">Message :</label><br>
    						<textarea id="message" name="message" cols="30" rows="8"></textarea></p>
    				</fieldset>
			    		<button type="submit" class="btn btn-success" id="valider" name="envoi">Envoyer</button>
    			</form>
        	</div>
		</section>
	</section>
	
	<script src="js/jquery-3.4.1.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/contact.js"></script>

	<section class="container-fluid bg-dark p-1">
		<div class="row">
			<div class="col-md-12 text-center text-danger">
				<p class="bas">@copyright 2019-2020 - All rights reserved to Auroria R&eacute;lePlay - 
					Design by Jacques Blake. <a type="button" class="btn btn-dark" href="mentions.html" role="button"> Mentions L&eacute;gales</a>
				</p>
			</div>
		</div>
	</section>
</body>
</html>